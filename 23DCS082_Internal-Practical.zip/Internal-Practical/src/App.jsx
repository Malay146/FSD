import React from 'react'
import Navbar from './components/Navbar'
import Home from './pages/Home'
import AnimatedRows from './components/AnimatedRows'
import Movies from './components/Movies'
import Footer from './components/Footer'

const App = () => {
  return (
    <div className='w-full bg-zinc-800'>
      <Navbar />
      <Home />
      <AnimatedRows />
      <Movies />
      <Footer />
    </div>
  )
}

export default App