import React, { useEffect, useState } from "react";
import Marquee from "react-fast-marquee";

const AnimatedRows = () => {
  const [movies, setMovies] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Fetch Avengers movies
    fetch("https://www.omdbapi.com/?s=avengers&apikey=9daf90bc")
      .then((response) => response.json())
      .then((data) => {
        if (data.Response === "True") {
          setMovies(data.Search); // Array of movies
        } else {
          setError(data.Error || "No movies found");
        }
      })
      .catch((err) => setError("Error: " + err.message));
  }, []);

  return (
    <div className="w-full bg-zinc-900 p-16">
        <h1 className="m-8 text-center text-white text-7xl font-bold">Movie Marquee</h1>
      {error && <p className="text-red-500">{error}</p>}

      <Marquee pauseOnHover={true} gradient={true} gradientColor="#18181b">
        {movies.map((movie, index) => (
          <div
            key={index}
            className="w-[20vw] h-[30vh] rounded-lg bg-zinc-400 mr-4 overflow-hidden"
          >
            <img
              className="w-full h-full object-cover bg-center"
              src={
                movie.Poster !== "N/A"
                  ? movie.Poster
                  : "https://via.placeholder.com/300x400?text=No+Image"
              }
              alt={movie.Title}
            />
          </div>
        ))}
      </Marquee>
    </div>
  );
};

export default AnimatedRows;
