import React from 'react'

const Navbar = () => {
  return (
    <div className='fixed font-light inset-0 bg-zinc-900 text-white h-[7vh] w-full flex justify-evenly items-center z-[9999]'>
        <h1>Home</h1>
        <h1>Movies</h1>
        <h1>Contact</h1>
    </div>
  )
}

export default Navbar