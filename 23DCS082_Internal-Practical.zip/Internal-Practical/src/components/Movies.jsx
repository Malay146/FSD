import React, { useEffect, useState } from "react";

const Movies = () => {
  const [movies, setMovies] = useState([]);
  const [error, setError] = useState(null);
  const [selectedMovie, setSelectedMovie] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Example: search for "Avengers"
    fetch("https://www.omdbapi.com/?s=avengers&apikey=9daf90bc")
      .then((response) => response.json())
      .then((data) => {
        if (data.Response === "True") {
          setMovies(data.Search); // Array of movies
        } else {
          setError(data.Error || "No movies found");
        }
      })
      .catch((err) => setError("Error: " + err.message));
  }, []);

  // Fetch full movie details when a card is clicked
  const handleMovieClick = (id) => {
    setLoading(true);
    fetch(`https://www.omdbapi.com/?i=${id}&apikey=9daf90bc`)
      .then((response) => response.json())
      .then((data) => {
        setSelectedMovie(data);
        setLoading(false);
      })
      .catch((err) => {
        setError("Error: " + err.message);
        setLoading(false);
      });
  };

  return (
    <div className="w-full bg-zinc-800 p-10 min-h-screen">
      <h1 className="text-white text-6xl mb-10 font-bold tracking-tighter underline">
        Know Your Movies
      </h1>

      <div className="w-full flex flex-wrap gap-7 justify-center">
        {error && <p className="text-red-500">{error}</p>}

        {movies.length > 0 ? (
          movies.slice(0, 8).map((movie, index) => (
            <div
              key={index}
              onClick={() => handleMovieClick(movie.imdbID)}
              className="cursor-pointer w-[20vw] h-[40vh] bg-zinc-500 rounded-lg overflow-hidden shadow-lg hover:scale-105 transition-transform duration-300"
            >
              <img
                className="w-full h-[75%] object-cover"
                src={
                  movie.Poster !== "N/A"
                    ? movie.Poster
                    : "https://via.placeholder.com/300x400?text=No+Image"
                }
                alt={movie.Title}
              />
              <div className="flex flex-col items-start p-3 text-white">
                <h4 className="font-semibold text-lg truncate">
                  {movie.Title}
                </h4>
                <h4 className="text-sm opacity-80">{movie.Year}</h4>
              </div>
            </div>
          ))
        ) : (
          !error && <p className="text-gray-300">Loading movies...</p>
        )}
      </div>

      {/* Modal */}
      {selectedMovie && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
          <div className="bg-zinc-900 text-white rounded-lg w-[80%] max-w-3xl p-6 relative shadow-xl">
            <button
              onClick={() => setSelectedMovie(null)}
              className="absolute top-3 right-3 text-2xl font-bold text-red-500 hover:text-red-400"
            >
              ✖
            </button>

            {loading ? (
              <p className="text-center">Loading...</p>
            ) : (
              <div className="flex flex-col md:flex-row gap-6">
                <img
                  className="w-full md:w-[40%] h-auto rounded-lg object-cover"
                  src={
                    selectedMovie.Poster !== "N/A"
                      ? selectedMovie.Poster
                      : "https://via.placeholder.com/300x400?text=No+Image"
                  }
                  alt={selectedMovie.Title}
                />
                <div className="flex flex-col gap-3">
                  <h2 className="text-3xl font-bold">{selectedMovie.Title}</h2>
                  <p className="text-gray-400 italic">{selectedMovie.Year} • {selectedMovie.Runtime}</p>
                  <p className="text-sm"><span className="font-semibold">Genre:</span> {selectedMovie.Genre}</p>
                  <p className="text-sm"><span className="font-semibold">Director:</span> {selectedMovie.Director}</p>
                  <p className="text-sm"><span className="font-semibold">Actors:</span> {selectedMovie.Actors}</p>
                  <p className="mt-2 text-gray-300">{selectedMovie.Plot}</p>
                  <p className="mt-2"><span className="font-semibold">IMDB Rating:</span> ⭐ {selectedMovie.imdbRating}</p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default Movies;
