import React from 'react'

const Footer = () => {
  return (
    <div className='flex justify-center items-center w-full h-[30vh] bg-zinc-900'>
        <h1 className='text-8xl font-bold text-center text-white'>Thanks For Your Time</h1>
    </div>
  )
}

export default Footer