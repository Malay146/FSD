import React from "react";
import { motion } from "framer-motion";

const Home = () => {
  return (
    <div className="w-full h-screen bg-cover bg-center flex justify-center items-center px-6">
      <div className="main max-w-4xl text-center">
        {/* Animated Title */}
        <motion.h1
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-6xl md:text-8xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 drop-shadow-lg"
        >
          Watch Your Favorite Movies
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 1 }}
          className="text-lg md:text-xl font-light text-zinc-400 mt-6"
        >
          Discover, explore, and enjoy movies like never before. Curated just
          for you 🎬✨
        </motion.p>

        {/* Call-to-Action Button */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 1 }}
          className="mt-10"
        >
          <button className="px-8 py-3 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white font-semibold text-lg shadow-lg hover:scale-105 transition-transform duration-300">
            Explore Movies
          </button>
        </motion.div>
      </div>
    </div>
  );
};

export default Home;
